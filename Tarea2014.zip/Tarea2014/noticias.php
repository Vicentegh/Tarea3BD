<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<h1>Noticias</h1>
<?Php
	include("conexion.php");
	$tipo = $_SESSION["tipo"];
	$query = "SELECT * FROM noticia";
	$resultado = pg_query($query);
	$cant = pg_num_rows($resultado);
	if($cant!=0)
		for($cont=0;$cont<$cant;$cont++){
			$row = pg_fetch_array($resultado,$cont);
			$titular = $row["titular"];
			$contenido = $row["contenido"];
			$id = $row["idnoticia"];
			echo "Titular: $titular<a href='editarN.php?id=$id'> Editar</a> <a href='eliminarN.php?id=$id'> Eliminar</a><br>
				Contenido: $contenido<br>";
		}
	else
		echo "aun no hay noticias<br>";
	echo "<a href='agregarN.php'>Agregar</a><br>";
	if($tipo==0)
		echo "<a href='menuCG.php'>Volver</a><br>";
	else
		echo "<a href='menuCA.php'>Volver</a><br>";

?>
</html>