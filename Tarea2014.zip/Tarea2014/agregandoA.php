<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?php
	include("conexion.php");
	$nombre = $_POST["nombre"];
	$cantidad = $_POST["cantidad"];
	if( strcmp($nombre,"")==0 || strcmp($cantidad,"")==0)
		echo "Falto llenar uno de los campos<br>
			<a href='agregarA.php' id='hover'>Volver</a>";
	else {
		$query = "INSERT INTO area (nombre, colaboradores) VALUES ('".$nombre."', ".$cantidad.")";
		pg_query($query);	
		echo "Se ah ingresado con exito la area<br>";	
		echo "<a href='areas.php' id='hover'>Volver</a>";		
	}
	
?>