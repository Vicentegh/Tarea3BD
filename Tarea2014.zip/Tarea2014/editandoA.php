<?php
	include("conexion.php");
	$nombre = $_POST["nombre"];
	$cantidad = $_POST["cantidad"];
	if(strcmp($nombre,"")==0 || strcmp($cantidad,"")==0)
		echo "Hay campos que faltaron ser rellenados<br>";
	else{
		$id = $_SESSION["idarea"];
		$query = "UPDATE area SET nombre = '".$nombre."', colaboradores = ".$cantidad." WHERE idarea = $id";
		$resultado = pg_query($query);
		echo "Se ah editado con exito <br>";
	}
	echo "<a href='areas.php' id='hover'>Volver</a>";		
?>