<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?php
	include("conexion.php");
	$id = $_GET["id"];
	$query = "Select * from area where idarea = $id";
	$resultado = pg_query($query);
	$row = pg_fetch_array($resultado,0);
	$nombre = $row["nombre"];
	echo "<h1>Esta seguro que quiere eliminar la area: $nombre?</h1><br>
		<a href='eliminandoA.php?id=$id' id='hover'>Si</a>
		<a href='areas.php' id='hover'>No</a>";
?>
</html>