<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<form method="post" action="agregandoA.php" enctype="multipart/form-data">
<h1> Ingresar los Datos <br></h1>
Nombre:<br>
<input type="text" name="nombre"><br>
Numero estimado de colaboradores:<br>
<input type="text" name="cantidad"><br>
<br><input type="submit" value="Ingresar"><br>
<a href="areas.php" id="hover">Volver</a><br>
</form>
</html>