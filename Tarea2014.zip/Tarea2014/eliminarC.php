<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?php
	include("conexion.php");
	$rol = $_GET["rol"];
	$query = "Select * from coordinador where rol = $rol";
	$resultado = pg_query($query);
	$row = pg_fetch_array($resultado,0);
	$nombre = $row["nombre"];
	echo "<h1>Esta seguro que quiere eliminar el coordinador: $nombre?</h1><br>
		<a href='eliminandoC.php?rol=$rol' id='hover'>Si</a>
		<a href='coordinadoresA.php' id='hover'>No</a>";
?>
</html>