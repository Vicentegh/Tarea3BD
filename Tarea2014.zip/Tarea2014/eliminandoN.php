<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?Php
	include("conexion.php");
	$id = $_GET["id"];
	$query = "Delete from noticia where idnoticia = $id";
	$eliminar = pg_query($query);
	echo "Se ah eliminado con exito<br>
		<a href='noticias.php' id='hover'>Volver</a>";
?>
</html>