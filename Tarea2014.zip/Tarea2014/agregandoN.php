<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?php
	include("conexion.php");
	$titular = $_POST["titular"];
	$contenido = $_POST["contenido"];
	$fecha = $_POST["fecha"];
	$area = $_POST["area"];
	if( strcmp($titular,"")==0 || strcmp($contenido,"")==0 || strcmp($fecha,"")==0)
		echo "Falto llenar uno de los campos<br>
			<a href='agregarN.php' id='hover'>Volver</a>";
	else {
		$rol = $_SESSION["rol"];
		$query = "INSERT INTO noticia (titular, contenido, fecha, area, rol) VALUES ('".$titular."', '".$contenido."', '".$fecha."', ".$area.", ".$rol.")";
		pg_query($query);	
		echo "Se ah ingresado con exito la noticia<br>";	
		echo "<a href='noticias.php' id='hover'>Volver</a>";		
	}
	
?>