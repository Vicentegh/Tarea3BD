<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?Php
	include("conexion.php");
	$query = "SELECT * FROM area";
	$resultado = pg_query($query);
	$cant = pg_num_rows($resultado);
	if($cant!=0)
		for($cont=0;$cont<$cant;$cont++){
			$row = pg_fetch_array($resultado,$cont);
			$tipo = $row["nombre"];
			$id = $row["idarea"];
			echo "Area: $tipo <a href='editarA.php?id=$id'> Editar</a> <a href='eliminarA.php?id=$id'> Eliminar</a><br>";
		}
	else
		echo "aun no hay areas<br>";
	echo "<a href='agregarA.php'>Agregar</a><br>
		<a href='menuCG.php'>Volver</a><br>";

?>
</html>