<?php
	include("conexion.php");
	$titular = $_POST["titular"];
	$contenido = $_POST["contenido"];
	$fecha = $_POST["fecha"];
	$area = $_POST["area"];
	if(strcmp($titular,"")==0 || strcmp($contenido,"")==0 || strcmp($fecha,"")==0)
		echo "Hay campos que faltaron ser rellenados<br>";
	else{
		$idN = $_SESSION["idN"];
		$query = "UPDATE noticia SET titular = '".$titular."', contenido = '".$contenido."', fecha = '".$fecha."', area = ".$area." WHERE idnoticia = $idN";
		$resultado = pg_query($query);
		echo "Se ah editado con exito <br>";
	}
	echo "<a href='noticias.php' id='hover'>Volver</a>";		
?>