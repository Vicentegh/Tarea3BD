<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<form method="post" action="agregandoP.php" enctype="multipart/form-data">
<h1> Ingresar los Datos <br></h1>
Nombre:<br>
<input type='text' name='nombre'><br>
ROL USM:<br>
<input type='text' name='rol'><br>
RUT:<br>
<input type='text' name='rut'><br>
<?php
	include("conexion.php");
	$query = "Select * from area";
	$resultado = pg_query($query);
	$cant = pg_num_rows($resultado);
	echo "Area:<br>
		<select name='area'>";	
	for($cont=0;$cont<$cant;$cont++){
		$area = pg_fetch_array($resultado,$cont);
		$nombre = $area["nombre"];
		$idA = $area["idarea"];
		echo "<option value='$idA'>$nombre</option>";
	}
	echo "</select><br>";
	$queryC = "Select * from carrera";
	$resultadoC = pg_query($queryC);
	$cant = pg_num_rows($resultadoC);
	echo "Carrera:<br>
		<select name='carrera'>";
	for($cont=0;$cont<$cant;$cont++){
		$carrera = pg_fetch_array($resultadoC,$cont);
		$nombre = $carrera["nombre"];
		$idC = $carrera["idcarrera"];
		echo "<option value='$idC'>$nombre</option>";
	}
	echo "</select><br>";
?>
Telefono:<br>
<input type='text' name='telefono'><br>
Correo electronico:<br>
<input type='text' name='correo'><br>
Contrasena:<br>
<input type='text' name='pass'><br>
<br><input type="submit" value="Ingresar"><br>
<a href="main.php" id="hover">Volver</a><br>
</form>
</html>