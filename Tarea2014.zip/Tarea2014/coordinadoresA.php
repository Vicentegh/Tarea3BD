<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?Php
	include("conexion.php");
	$query = "SELECT * FROM coordinador";
	$resultado = pg_query($query);
	$cant = pg_num_rows($resultado);
	if($cant-1!=0){
		$rolC = $_SESSION["rol"];
		for($cont=0;$cont<$cant;$cont++){
			$row = pg_fetch_array($resultado,$cont);
			$nombre = $row["nombre"];
			$rol = $row["rol"];
			if(strcmp($rol,$rolC)!=0)
				echo "Nombre: $nombre <a href='editarC.php?rol=$rol'> Editar</a> <a href='eliminarC.php?rol=$rol'> Eliminar</a><br>";
		}
	}
	else
		echo "aun no hay otros Coordinadores<br>";
	echo "<a href='agregarC.php'>Agregar</a><br>
		<a href='menuCG.php'>Volver</a><br>";

?>
</html>