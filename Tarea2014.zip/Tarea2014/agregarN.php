<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<form method="post" action="agregandoN.php" enctype="multipart/form-data">
<h1> Ingresar los Datos de la noticia<br></h1>
Titular:<br>
<input type="text" name="titular"><br>
Contenido de la Noticia:<br>
<input type="text" name="contenido"><br>
Fecha de publicacion:<br>
<input type="text" name="fecha"><br>
<?php
	include("conexion.php");
	$tipo = $_SESSION["tipo"];
	if($tipo==0){
		$query = "Select * from area";
		$resultado = pg_query($query);
		$cant = pg_num_rows($resultado);
		echo "Area:<br>
			<select name='area'>";	
		for($cont=0;$cont<$cant;$cont++){
			$area = pg_fetch_array($resultado,$cont);
			$nombre = $area["nombre"];
			$idA = $area["idarea"];
			echo "<option value='$idA'>$nombre</option>";
		}
		echo "</select><br>";
	} else {
		$rol = $_SESSION["rol"];
		$query = "Select * from coordinador where rol = $rol";
		$resultado = pg_query($query);
		$row = pg_fetch_array($resultado,0);
		$idA = $row["idarea"];
		$queryA = "Select * from area where idarea = $idA";
		$resultadoA = pg_query($queryA);
		$rowA = pg_fetch_array($resultadoA,0);
		$nombre = $rowA["nombre"];
		echo "Area: <br>
			<select name='area'>
			<option value='$idA'>$nombre</option>
			</select><br>";
	}
?>
<br><input type="submit" value="Ingresar"><br>
<a href="noticias.php" id="hover">Volver</a><br>
</form>
</html>