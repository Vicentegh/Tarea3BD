<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?Php
	include("conexion.php");
	$id = $_GET["id"];
	$query = "Delete from area where idarea = $id";
	$eliminar = pg_query($query);
	echo "Se ah eliminado con exito<br>
		<a href='areas.php' id='hover'>Volver</a>";
?>
</html>