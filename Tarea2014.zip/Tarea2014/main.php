<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


</head>
<body>
<form method="post" action="comprobarU.php" enctype="multipart/form-data">
Ingrese los datos 
<br>
<br>
</br>
Rol <br><input type="text" name="user" id="user" MAXLENGTH=30>
</br>
Contrasena<br> <input type="password" name="contrasena" id="contrasena">
<br>

<br><br>
<input type="submit" value="Ingresar">
</form>
<br><a href="agregarP.php" id="hover">Postular</a><br>


</body>
</html>