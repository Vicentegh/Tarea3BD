<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?php
	include("conexion.php");
	$id = $_GET["id"];
	$query = "Select * from noticia where idnoticia = $id";
	$resultado = pg_query($query);
	$row = pg_fetch_array($resultado,0);
	$titular = $row["titular"];
	echo "<h1>Esta seguro que quiere eliminar la Noticia: $titular?</h1><br>
		<a href='eliminandoN.php?id=$id' id='hover'>Si</a>
		<a href='noticias.php' id='hover'>No</a>";
?>
</html>