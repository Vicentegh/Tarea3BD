<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?php
	include("conexion.php");
	$nombre = $_POST["nombre"];
	$rol = $_POST["rol"];
	$rut = $_POST["rut"];
	$correo = $_POST["correo"];
	$pass = $_POST["pass"];
	$idC = $_POST["carrera"];
	$idA = $_POST["area"];
	$telefono = $_POST["telefono"];
	if( strcmp($nombre,"")==0 || strcmp($rol,"")==0 || strcmp($rut,"")==0 || strcmp($correo,"")==0 || strcmp($pass,"")==0 || strcmp($telefono,"")==0)
		echo "Falto llenar alguno de los campos<br>
			<a href='agregarP.php' id='hover'>Volver</a>";
	else {
		$query = "INSERT INTO postulante (rol, nombre, contrasena, rut, correo, idcarrera, idarea, telefono) VALUES (".$rol.", '".$nombre."', '".$pass."', ".$rut.", '".$correo."', ".$idC.", ".$idA.", ".$telefono.")";
		pg_query($query);	
		echo "Te as agregado con exito CTM<br>";	
		echo "<a href='main.php' id='hover'>Volver</a>";		
	}

?>