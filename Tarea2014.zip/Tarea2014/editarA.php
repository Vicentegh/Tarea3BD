<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<form method="post" action="editandoA.php" enctype="multipart/form-data">
<?php
	include("conexion.php");
	$id = $_GET["id"];
	$_SESSION["idarea"]=$id;
	$query = "SELECT * FROM area WHERE idarea = $id";
	$resultado = pg_query($query);
	$row = pg_fetch_array($resultado,0);
	$nombre = $row["nombre"];
	$cantidad = $row["colaboradores"];
	echo "Nombre:<br> <input type='text' name='nombre' value='$nombre'><br>
		Cantidad de Colaboradores:<br> <input type='text' name='cantidad' value='$cantidad'><br>";
	
?>
<br><input type="submit" value="Editar"><br>
<a href="areas.php" id="hover">Volver</a><br>
</form>