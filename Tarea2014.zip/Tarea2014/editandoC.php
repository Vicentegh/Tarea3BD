<?php
	include("conexion.php");
	$rolA = $_SESSION["rolA"];
	$nombre = $_POST["nombre"];
	$rol = $_POST["rol"];
	$rut = $_POST["rut"];
	$correo = $_POST["correo"];
	$talla = $_POST["talla"];
	$pass = $_POST["pass"];
	$idC = $_POST["carrera"];
	$idA = $_POST["area"];
	$telefono = $_POST["telefono"];
	if( strcmp($nombre,"")==0 || strcmp($rol,"")==0 || strcmp($rut,"")==0 || strcmp($correo,"")==0 || strcmp($talla,"")==0 || strcmp($pass,"")==0 || strcmp($telefono,"")==0)
		echo "Falto llenar alguno de los campos<br>";
	else {
		$query = "Update coordinador set rol = ".$rol.", nombre = '".$nombre."', contrasena = '".$pass."', rut = ".$rut.", correo = '".$correo."', talla = ".$talla.", idcarrera = ".$idC.", idarea = ".$idA.", telefono = ".$telefono." where rol = $rolA";
		pg_query($query);	
		echo "Se ah editado con exito el coordinador<br>";	
	}
	//, set rut = ".$rut.", set correo = '".$correo."', set talla = ".$talla.", set idcarrera = ".$idC.", set idarea = ".$idA.", set telefono = ".$telefono."
	echo "<a href='coordinadoresA.php' id='hover'>Volver</a>";	
?>