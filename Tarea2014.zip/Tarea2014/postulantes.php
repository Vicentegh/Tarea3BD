<?php
	include("conexion.php");
	$tipo = $_SESSION["tipo"];	
	$entro = $_SESSION["entro"];
	if($entro!=1){
		if($tipo==0){
			$_SESSION["entro"] = 1;
			echo "<form method='post' action='postulantes.php' enctype='multipart/form-data'>";
			echo "<h1>Escoja el area</h1>";
			$query = "Select * from area";
			$resultado = pg_query($query);
			$cant = pg_num_rows($resultado);
			echo "Area:<br>
				<select name='area'>";	
			for($cont=0;$cont<$cant;$cont++){
				$area = pg_fetch_array($resultado,$cont);
				$nombre = $area["nombre"];
				$idA = $area["idarea"];
				echo "<option value='$idA'>$nombre</option>";
			}
			echo "</select><br>";
			echo "<input type='submit' value='Ir'>
				</form>";
		} 	
		else {
			echo "<form method='post' action='agregandoP.php' enctype='multipart/form-data'>";
			$rol = $_SESSION["rol"];
			$query = "Select * from coordinador where rol = $rol";
			$resultado = pg_query($query);
			$row = pg_fetch_array($resultado,0);	
			$idA = $row["idarea"];
			$query = "Select * from area where idarea = $idA";
			$resultado = pg_query($query);
			$row = pg_fetch_array($resultado,0);
			$nombre = $row["nombre"];		
			echo "<h1>Postulantes del area: $nombre</h1>";
			$queryP = "Select * from postulante where idarea = $idA";
			$resultadoP = pg_query($queryP);
			$cant = pg_num_rows($resultadoP);
			if($cant!=0){
				echo "Postulante:<br>
				<select name='postulante'>";	
				for($cont=0;$cont<$cant;$cont++){
					$postulante = pg_fetch_array($resultadoP,$cont);
					$nombre = $postulante["nombre"];
					$idA = $postulante["idarea"];
					echo "<option value='$idA'>$nombre</option>";
				}
				echo "</select><br>";
				echo "<br><input type='submit' value='Ingresar'>
					</form>";
			}
			else
				echo "Aun no hay postulantes en esta area";			
		}
	}
	else {
		echo "<form method='post' action='agregandoP.php' enctype='multipart/form-data'>";
		$_SESSION["entro"] = 0;
		$idA = $_POST["area"];
		$queryP = "Select * from postulante where idarea = $idA";
		$resultadoP = pg_query($queryP);
		$cant = pg_num_rows($resultadoP);
		$query = "Select * from area where idarea = $idA";
		$resultado = pg_query($query);
		$row = pg_fetch_array($resultado,0);
		$nombre = $row["nombre"];	
		echo "<h1>Postulantes del area: $nombre</h1>";
		if($cant!=0){
			echo "Postulante:<br>
			<select name='postulante'>";	
			for($cont=0;$cont<$cant;$cont++){
				$postulante = pg_fetch_array($resultadoP,$cont);
				$nombre = $postulante["nombre"];
				$idA = $postulante["idarea"];
				echo "<option value='$idA'>$nombre</option>";
			}
			echo "</select><br>";
			echo "<br><input type='submit' value='Ingresar'>
				</form>";
		}		
		else
			echo "Aun no hay postulantes en esta area";	
	}
	if($tipo==0)
		echo "<br><a href='menuCG.php' id='hover'>Volver</a>";
	else
		echo "<br><a href='menuCA.php' id='hover'>Volver</a>";
?>
