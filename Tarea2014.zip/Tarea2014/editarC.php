<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<form method="post" action="editandoC.php" enctype="multipart/form-data">
<h1> Editar los Datos <br></h1>
<?php
	include("conexion.php");
	$rol = $_GET["rol"];
	$_SESSION["rolA"]=$rol;
	$query = "Select * from coordinador where rol = $rol";
	$resultado = pg_query($query);
	$row = pg_fetch_array($resultado,0);
	$nombre = $row["nombre"];
	$rol = $row["rol"];
	$rut = $row["rut"];
	$correo = $row["correo"];
	$talla = $row["talla"];
	$pass = $row["contrasena"];
	$idC = $row["idcarrera"];
	$idA = $row["idarea"];
	$telefono = $row["telefono"];
	echo "Nombre:<br>
		<input type='text' name='nombre' value=$nombre><br>
		ROL USM:<br>
		<input type='text' name='rol' value=$rol><br>
		RUT:<br>
		<input type='text' name='rut' value=$rut><br>";
	$query = "Select * from area";
	$resultado = pg_query($query);
	$cant = pg_num_rows($resultado);
	echo "Area:<br>
		<select name='area'>";	
	for($cont=0;$cont<$cant;$cont++){
		$area = pg_fetch_array($resultado,$cont);
		$nombre = $area["nombre"];
		$idA = $area["idarea"];
		echo "<option value='$idA'>$nombre</option>";
	}
	echo "</select><br>";
	$queryC = "Select * from carrera";
	$resultadoC = pg_query($queryC);
	$cant = pg_num_rows($resultadoC);
	echo "Carrera:<br>
		<select name='carrera'>";
	for($cont=0;$cont<$cant;$cont++){
		$carrera = pg_fetch_array($resultadoC,$cont);
		$nombre = $carrera["nombre"];
		$idC = $carrera["idcarrera"];
		echo "<option value='$idC'>$nombre</option>";
	}
	echo "</select><br>";
	echo "Telefono:<br>
		<input type='text' name='telefono' value=$telefono><br>
		Talla de polera:<br>
		<input type='text' name='talla' value=$talla><br>
		Correo electronico:<br>
		<input type='text' name='correo' value=$correo><br>
		Contrasena:<br>
		<input type='text' name='pass' value=$pass><br>";
?>
<br><input type="submit" value="Editar"><br>
<a href="coordinadoresA.php" id="hover">Volver</a><br>
</form>
</html>