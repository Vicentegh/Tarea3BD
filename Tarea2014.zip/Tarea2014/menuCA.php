<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<h1> Opciones: <br></h1>
<a href="misDatos.php" id="hover">Mis Datos</a><br>
<a href="noticias.php" id="hover">Noticias</a><br>
<a href="postulantes.php" id="hover">Postulantes</a><br>
<a href="colaboradoresS.php" id="hover">Colaboradores Seleccionados</a><br>
<a href="main.php" id="hover">Cerrar Sesion</a><br>
</html>
