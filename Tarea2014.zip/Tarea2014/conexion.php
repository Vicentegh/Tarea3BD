<?php
	session_start();
	$conexion = pg_connect("user = postgres password = admin port = 5432 dbname = Tarea2014 host = localhost");
?>