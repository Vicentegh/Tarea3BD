<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?Php
	session_start();
	include("conexion.php");
    $rol = $_POST['user'];
	$contrasena = $_POST['contrasena'];
	if( strcmp($rol,"") == 0 && strcmp($contrasena,"") == 0 ){
		echo "Falta llenar uno de los datos, por favor intentelo de nuevo <br>
				<a href='main.php'>Volver</a><br>";
	}
	else {
		$query = "SELECT * FROM coordinador where rol = ".$rol." and contrasena = '".$contrasena."'";
		$resultado = pg_query($query);
		$row = pg_fetch_array($resultado,0);
		if($row){
			$tipo = $row["tipo"];
			$_SESSION["rol"]=$rol;
			$_SESSION["tipo"]=$tipo;
			switch ($tipo){
				case 0:
					header("Location: http://localhost:8080/tarea2014/menuCG.php");
				break;
				case 1:
					header("Location: http://localhost:8080/tarea2014/menuCA.php");
				break;
				default:
				break;
			}
		}
		else
			echo "Clave o usuario equivocado <br>
				<a href='main.php'>Volver a intentarlo</a><br>";
	}
	
?>
</html>