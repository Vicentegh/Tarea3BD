<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?php
	include("conexion.php");
	$nombre = $_POST["nombre"];
	$rol = $_POST["rol"];
	$rut = $_POST["rut"];
	$correo = $_POST["correo"];
	$talla = $_POST["talla"];
	$pass = $_POST["pass"];
	$idC = $_POST["carrera"];
	$idA = $_POST["area"];
	$telefono = $_POST["telefono"];
	if( strcmp($nombre,"")==0 || strcmp($rol,"")==0 || strcmp($rut,"")==0 || strcmp($correo,"")==0 || strcmp($talla,"")==0 || strcmp($pass,"")==0 || strcmp($telefono,"")==0)
		echo "Falto llenar alguno de los campos<br>
			<a href='agregarC.php' id='hover'>Volver</a>";
	else {
		$query = "INSERT INTO coordinador (rol, nombre, contrasena, rut, correo, talla, idcarrera, idarea, telefono, tipo) VALUES (".$rol.", '".$nombre."', '".$pass."', ".$rut.", '".$correo."', ".$talla.", ".$idC.", ".$idA.", ".$telefono.", 1)";
		pg_query($query);	
		echo "Se ah ingresado con exito el coordinador<br>";	
		echo "<a href='coordinadoresA.php' id='hover'>Volver</a>";		
	}

?>