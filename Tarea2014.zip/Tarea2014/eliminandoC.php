<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<?Php
	include("conexion.php");
	$rol = $_GET["rol"];
	$query = "Delete from coordinador where rol = $rol";
	$eliminar = pg_query($query);
	echo "Se ah eliminado con exito<br>
		<a href='coordinadoresA.php' id='hover'>Volver</a>";
?>
</html>